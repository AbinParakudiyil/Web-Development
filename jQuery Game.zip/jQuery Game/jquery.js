var playing = false;
var score;
var trialsleft;
var step;
var action;
var instruction="The idea is you've to chop the fruits each time and you scores.\nIf you chop a fruit you get an extra points.\nIf you miss a fruit you lose a life.";
var fruits = ['apple','orange','pineapple','peach','pear','papaya','mango','grapes','cherries','watermelon'];
$(function(){
    //click on start reset button
 $("#startgame").click(function(){
      //are we playing?
      if(playing == true){//yes
       //reload page
       location.reload();
        }else{     //no
         playing = true; //game initiated
         //set score to 0
         score = 0;
         
         $("#scorevalue").html(score);
         //show trials left
         $("#trialsleft").show();
         trialsleft = 3;
         addHearts();
         //hide game over box
         $("#gameover").hide();
                //change button text to reset 
        $("#startgame").html("RESET");
        //start sending fruits
        startAction();
       }
 });
$("#fruit1").mouseover(function(){
 score++;
 $("#scorevalue").html(score);//update score
 $("#slicesound")[0].play();//play sound
 //stop fruit 
 clearInterval(action);
 //hide fruit
 $("#fruit1").hide("explode",500); //slice fruit
//send new fruit
setTimeout(startAction,500);
});
 //functions
function addHearts(){
  $("#trialsleft").empty();
    for(i=0; i<trialsleft; i++){
        $("#trialsleft").append('<img src="images/red_heart.jpg" class="heart">');
             }
}
function startAction(){
  //generate a fruit
 $("#fruit1").show();
 chooseFruit();//choose a random fruit
 $("#fruit1").css({'left':Math.round(900*Math.random()), 'top':-50});//random position
 //generate a random step
 step =1 + Math.round(5 * Math.random());//change step

 //move fruit down by one step every 10ms
 action = setInterval(function(){
  $("#fruit1").css('top',
  $("#fruit1").position().top + step);//move the fruit by one step
  //check if the fruit is too low
  if($("#fruit1").position().top>$("#fruitcontainer").height()){
   //check if we have trials left
   if(trialsleft > 1){
    //generate a fruit
 $("#fruit1").show();
 chooseFruit();//choose a random fruit
 $("#fruit1").css({'left':Math.round(900*Math.random()), 'top':-50});//random position
 //generate a random step
 step = 1 + Math.round(10* Math.random());//change step
    //reduce trials by one
    trialsleft--;
    addHearts();
   }else{//game over
       playing = false;//we are not playing 
       $("#startgame").html("START");//change button to start
       $("#gameover").show();
       $("#gameover").html('<p>Game Over!</p><p>Your score is '+score+'</p>');
       $("#trialsleft").hide();
       stopAction();

   }
  }
 },10);
}  
        
//generate a random fruit
function chooseFruit(){
  $("#fruit1").attr('src' , 'images/' + fruits[Math.round(9*Math.random())] +'.png');
}
function stopAction(){
  clearInterval(action);
  $("#fruit1").hide();

}
});

      

