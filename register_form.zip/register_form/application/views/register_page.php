<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <input type="hidden" id="id" value="<?php echo $id ?> " />
</head>
<style>
    /* .container {
        width: 600px;
        color: grey;
        
    } */
</style>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">

            <div class="col-md-10">
                <h3><?php echo $title ?> </h3>

            </div>
        </div>
        </div>
        </div>
    </nav>

    <div class="container">

        <form method="post"  action="<?php echo base_url('test/save') ?>">
            <div class="form-group">
                <div class="col-sm-12">
                    <div class="col-sm-6">

                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter User name" name="name" required>
                    </div>


                    <div class="col-sm-6">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
                    </div>
                </div>
                <div class="col-sm-12">

                    <div class="col-sm-6">

                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                    </div>
                    <div class="col-sm-6">
                        <label>Choose your gender:</label>
                        <label for="male">Male</label>
                        <input type="checkbox" name="gender" id="male" value="male">
                        <label for="female">Female</label>
                        <input type="checkbox" name="gender" id="female" value="female">
                    </div>
                </div>
                <div class="col-sm-12">


                    <div class="col-sm-6">
                        <label for="contact">Contact:</label>
                        <input type="number" class="form-control" id="contact" placeholder="Enter Contact Number" name="contact" required>
                    </div>

                    <div class="col-sm-6">
                    <form id="upload_form">

                        <label for="file">Image:</label>
                        <input type="file" class="form-control" id="image" name="image">
                    </div>
                    <!-- <div class="col-sm-3">
                    <br>
                        <button type="button" class="btn btn-success">Upload image</button>
                    </div> -->
                <!-- </form> -->
                </div>
                <div class="col-sm-12">

                    <div class="col-sm-6">
                        <label for="place">Place:</label>
                        <select type="text" class="form-control" id="place" placeholder="Enter your place" name="place">
                        <option value="kochi">Kochi</option>
                        <option value="kollam">kollam</option>
                        </select>
                    </div>

                </div>
                <div class="col-sm-6">

                        <button type="submit" class="btn btn-success">Register</button>
                    </div>
            </div>


        </form>
    </div>
    

</body>

</html>

<script type="text/javascript">
    var id = $("#id").val();
    if (id > 0) {
        $.ajax({
            url: "<?php echo site_url('Test/view_data'); ?>/" + id,
            success: function(results) {
                var result = JSON.parse(results);

                $("#name").val(result.name);
                $("#gender").val(result.gender);
                $("#email").val(result.email);
                $("#password").val(result.password);
                $("#contact").val(result.contact);
                // $("#city_name").val(result.city_name);
                // $("#description").val(result.description);



            }
        });

    }

//     $(document).ready(function(){  
//       $('#upload_form').on('submit', function(e){  
//            e.preventDefault();  
//         //    if($('#image').val() == '')  
//         //    {  
//         //         alert("Please Select the File");  
//         //    }  
//         //    else  
//         //    {  
//                 $.ajax({  
//                      url:"<?php echo site_url('Test/image_upload'); ?>/" ,   
//                      //base_url() = http://localhost/tutorial/codeigniter  
//                      method:"POST",  
//                      data:new FormData(this),  
//                      contentType: false,  
//                      cache: false,  
//                      processData:false,  
//                      success:function(data)  
//                      {  
//                           alert('image Successfully inserted');
//                      }  
//                 });  
//           // }  
//       });  
//  }); 

</script>