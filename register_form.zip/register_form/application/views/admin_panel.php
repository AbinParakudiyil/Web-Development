<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
    .container {
        width: 600px;
        color: grey;
        
    }
</style>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
                 
            <div class="col-md-10">
            <h3><?php echo $title ?></h3>
            <span class="pull-right">
                   if you dont have an account then <a  href='<?php echo base_url('test/register_page/')?>' class="btn btn-primary" value="SIgnUp">SignUp</a>

                </span>
            </div>
        </div>
        </div>
        </div>
    </nav>

    <div class="container">

    <form method="post" action="<?php echo base_url('test/signin') ?>">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="name" class="form-control" id="name" placeholder="Enter name" name="name" required>
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
            </div>
            <div class="checkbox">
                <label><input type="checkbox" name="remember"> Remember me</label>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
        </form>
    </div>

</body>

</html>