<?php
class Test_model extends CI_model
{

    public function save()
    {
        $this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required');
        if ($this->form_validation->run() == false) {
            redirect('test/index');
        } else {
            $name = $this->input->post('name');
            $password = $this->input->post('password');
            $email = $this->input->post('email');
            $image = $this->input->post('image');
            $contact = $this->input->post('contact');
            $gender = $this->input->post('gender');
            $place = $this->input->post('place');


            $data = array(
                'name' => $name,
                'password' => $password,
                'email' => $email,
                'image' => $image,
                'contact' => $contact,
                'gender' => $gender,
                'place' => $place

            );

            $this->db->insert('reg_table', $data);

            redirect('test/index');
        }
    }
    public function signin()
    {
        $name = $this->input->post('name');
        $password = $this->input->post('password');

           
           $qry ="SELECT * FROM reg_table WHERE name = '$name' AND password = '$password'  ";
           $query = $this->db->query($qry);  
         
           if($query->num_rows() > 0)  
           {  
                 $data = 1;
                 redirect('test/register_page/'.$data);
           }  
           else  
           {  
                    redirect('test/index');       
           }  
       

    }
    
    function view_data($id) {
        $qry = "select * from reg_table where id= ".$id;
        $result = $this->db->query($qry);
        echo json_encode($result->row_array());

    }
}
