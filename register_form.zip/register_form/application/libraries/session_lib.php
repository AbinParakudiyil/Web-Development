<?php  
 $autoload['libraries'] = array('database', 'session');   
 //For Load Session Library in this application  
 ?> 