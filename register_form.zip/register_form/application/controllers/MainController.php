<?php
class Test extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Test_model', 'test');
        // $this->load->library('pdf');
    }
    public function register_page()
    {
        $this->load->view('register_page');
    }
}