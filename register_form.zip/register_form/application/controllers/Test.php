<?php
class Test extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Test_model', 'test');
        // $this->load->library('pdf');
    }

    public function index()
    {
        $data['title'] = 'Admin Panel';
        $this->load->view('admin_panel',$data);
    }
    public function register_page($id=0)
    { 
        print_r($id);
        $data['id'] = $id;
        $data['title'] = "Register Page";
        $this->load->view('register_page',$data);
    }
    public function save()
    {
         $this->test->save();        
    }
   public function signin()
   {
       $this->test->signin();
   }
   public function view_data($id)
   {
       $this->test->view_data($id);
   }
   function image_upload()  
      {  
           if(isset($_FILES["image"]["name"]))  
           {  
                $config['upload_path'] = './upload/';  
                $config['allowed_types'] = 'jpg|jpeg|png|gif';  
                $this->load->library('upload', $config);  
                if(!$this->upload->do_upload('image'))  
                {  
                     echo $this->upload->display_errors();  
                }  
                else  
                {  
                     $data = $this->upload->data();  
                     echo '<img src="'.base_url().'upload/'.$data["file_name"].'" width="300" height="225" class="img-thumbnail" />';  
                }  
           }  
      }
}
